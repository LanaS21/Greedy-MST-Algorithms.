/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphFramework;

import java.util.*;

import RoadDesignApp.Road;

public class PQPrimAlg extends MSTAlgorithem {

	public PQPrimAlg(Graph graph) {

		super(graph);
	}

	public void PQ(Graph graph) {

		MSTresultList = new LinkedList<>(); // add the result to linked list

		PriorityQueue<Road> PQ = new PriorityQueue<>(Comparator.comparingInt(o -> o.weight));

		// add vertices
		add(PQ, graph.vertices.get(0));

		while (!PQ.isEmpty()) {
			Road edge = PQ.poll();
			// check not add vertices visited vertices
			if (edge.target.isVisited) {
				continue;
			}

			MSTresultList.add(new Road(edge.source, edge.target, edge.weight));

			add(PQ, edge.target);
		}

	}

	// add all connected edges with vertex
	public void add(PriorityQueue<Road> pq, Vertex source) {
		source.isVisited = true;
		for (Edge road : source.adjlist) {
			if (graph.vertices.get(road.target.label).isVisited == false) {
				pq.add((Road) road);
			}
		}
	}

	@Override
	public void DisplayResultingMST() {

		int cost = 0;
		System.out.println("The road map (minimum spanning tree) Priority-queue Prim algorithm is as follows:");
		for (int i = 0; i < MSTresultList.size(); i++) {
			Road road = (Road) MSTresultList.get(i);
			cost += road.weight;
			road.displayInfo();
		}
		System.out.println("The cost of designed roads: " + cost);

	}
}

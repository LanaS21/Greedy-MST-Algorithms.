 package graphFramework;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import RoadDesignApp.House;
import RoadDesignApp.Road;

public class Graph {
	int verticesNo;
	int edgeNo;
	boolean isDigraph = false;//is the graph directed or no
	ArrayList<Vertex> vertices = new ArrayList<Vertex>();

	public Graph() {

	}

	public Graph(int verticesNo, int edgeNo, boolean isDigraph) {
		this.verticesNo = verticesNo;
		this.edgeNo = edgeNo;
		this.isDigraph = isDigraph;

	}

	public void makeGraph() {
		// random class
		Random random = new Random();
 
		for (int i = 0; i < verticesNo; i++) {//go throuh all the vetices and insulize them
			vertices.add(new House(i, "x" + i));
		}

		// check that all vertices are connected
		for (int i = 0; i < verticesNo - 1; i++) {
			int RandomNum = random.nextInt(10) + 1;
			addEdge(vertices.get(i), vertices.get(i + 1), RandomNum);

		}

		// Remaining edge
		int remaning = edgeNo - (verticesNo - 1);

		for (int i = 0; i < remaning; i++) {
			Vertex source = vertices.get(random.nextInt(verticesNo));
			Vertex Destination = vertices.get(random.nextInt(verticesNo));

			int weight = random.nextInt(20) + 1;
			// to avoid duplicate edges
			if (source == Destination || isConnected(source, Destination)) {
				i--;//rebeat again
			} else {
				// add edge to graph 
				addEdge(source, Destination, weight);
			}
		}
		// reset the edgeNo count
		this.edgeNo = remaning + (verticesNo - 1);
	}

	public void readGraphFromFile(String fileName) throws FileNotFoundException {
		File file = new File(fileName);
		Scanner scanner = new Scanner(file);

		this.isDigraph = scanner.nextLine().trim().equalsIgnoreCase("digraph 1");
		this.verticesNo = scanner.nextInt();//read the number
		this.vertices = new ArrayList<Vertex>();//insulize the array list

		// create all vertices

		int edgeNo = scanner.nextInt();//read number of edges
		int count = 0;
		for (int m = 0; m < edgeNo; m++) {
			Vertex sHouse = getHouseOrCreate(new House(scanner.next()));//read the first letter
			if (sHouse.label == -1)//to know is the vertex new
				sHouse.label = count++;//give new label
			Vertex tHouse = getHouseOrCreate(new House(scanner.next()));
			if (tHouse.label == -1)
				tHouse.label = count++;
			int EdgeWeight = scanner.nextInt();// read the weight
			addEdge(sHouse, tHouse, EdgeWeight);
		}
		scanner.close();
	}

	public void addEdge(Vertex source, Vertex target, int weight) {
		Road road = new Road(source, target, weight);
		source.adjlist.addFirst(road);
		if (isDigraph) {
			this.edgeNo += 1;//add just one edge
		} else {
                    //add to the opposite direction
			road = new Road(target, source, weight);
			target.adjlist.addFirst(road);
			this.edgeNo += 2;
		}
	}

	public boolean isConnected(Vertex Source, Vertex target) {
		for (Edge edge : Source.adjlist) {
			if (edge.target == target) {
				return true;
			}
		}
		return false;
	}

	public Vertex getHouseOrCreate(House searchHouse) {
		for (Vertex vertex : vertices)//search if the vertex in the list
			if (vertex.equals(searchHouse)) {
				return vertex;
			}
		vertices.add(searchHouse);//not found make new in the list
		return vertices.get(vertices.size() - 1);
	}

}

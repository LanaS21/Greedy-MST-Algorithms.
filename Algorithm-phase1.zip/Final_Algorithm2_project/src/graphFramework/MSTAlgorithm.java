/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphFramework;

import java.util.*;

abstract class MSTAlgorithem {

	Graph graph;
	LinkedList<Edge> MSTresultList = new LinkedList<>();

	public MSTAlgorithem(Graph graph) {
		this.graph = graph;

	}

	public abstract void DisplayResultingMST();

}
